import cmath

if __name__ == "__main__":
    num = eval(input())
    print(abs(num))
    print(cmath.phase(num))
