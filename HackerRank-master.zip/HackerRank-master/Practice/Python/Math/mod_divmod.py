if __name__ == '__main__':
    m = int(input())
    n = int(input())
    print(m//n)
    print(m%n)
    print(divmod(m,n))
