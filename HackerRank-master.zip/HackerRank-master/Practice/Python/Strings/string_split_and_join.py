def split_and_join(line):
    return '-'.join(line.split(" "))
