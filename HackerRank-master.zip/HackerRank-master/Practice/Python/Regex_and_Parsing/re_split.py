import re
for e in re.split(r"[.,]", input()):
    if e:
        print(e)
