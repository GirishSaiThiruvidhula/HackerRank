if __name__ == '__main__':
    x, k = [int(i) for i in input().split()]
    print(eval(input()) == k)
